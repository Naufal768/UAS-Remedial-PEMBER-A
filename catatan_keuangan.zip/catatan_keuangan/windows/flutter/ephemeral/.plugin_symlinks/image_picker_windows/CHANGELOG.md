## 0.2.1+1

* Adds pub topics to package metadata.
* Updates minimum supported SDK version to Flutter 3.7/Dart 2.19.

## 0.2.1

* Adds `getMedia` method.

## 0.2.0

* Updates minimum Flutter version to 3.3.

## 0.1.0+6

* Clarifies explanation of endorsement in README.
* Aligns Dart and Flutter SDK constraints.

## 0.1.0+5

* Updates links for the merge of flutter/plugins into flutter/packages.

## 0.1.0+4

* Updates example code for `use_build_context_synchronously` lint.
* Updates minimum Flutter version to 3.0.

## 0.1.0+3

* Changes XTypeGroup initialization from final to const.
* Updates minimum Flutter version to 2.10.

## 0.1.0+2

* Minor fixes for new analysis options.

## 0.1.0+1

* Removes unnecessary imports.
* Fixes library_private_types_in_public_api, sort_child_properties_last and use_key_in_widget_constructors
  lint warnings.

## 0.1.0

* Initial Windows support.
