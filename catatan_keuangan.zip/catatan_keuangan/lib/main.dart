// =============================================
// Nama Lengkap : Muhammad Naufal Widiatmoko
// NIM          : 230441100125
// Kelas        : Pemrograman Bergerak A (PEMBER A)
// Nama Asprak  : Muhammad Rosyid Maulana
// =============================================

import 'package:flutter/material.dart';
import 'home.dart';
import 'add_note.dart';
import 'detail_note.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Catatan Keuangan',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Poppins',
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/add': (context) => AddNoteScreen(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/detail') {
          final args = settings.arguments;
          if (args is Map<String, dynamic>) {
            return MaterialPageRoute(
              builder: (context) => DetailNoteScreen(data: args),
            );
          }
        }
        return null; // fallback jika tidak dikenali
      },
    );
  }
}
