import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'add_note.dart';
import 'package:permission_handler/permission_handler.dart';

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, dynamic>> _data = [];
  int _saldo = 0;
  final Map<String, String> _localImages = {}; // id -> image path

  final String url = 'https://uas-remedial-default-rtdb.firebaseio.com//catatan.json';

  Future<void> fetchData() async {
    final response = await http.get(Uri.parse(url));
    final extracted = jsonDecode(response.body) as Map<String, dynamic>?;

    if (extracted != null) {
      final List<Map<String, dynamic>> loaded = [];
      int total = 0;
      extracted.forEach((key, value) {
        final item = Map<String, dynamic>.from(value);
        item['id'] = key;
        loaded.add(item);

        if (item['jenis'] == 'Pemasukan') {
          total += (item['jumlah'] as num).toInt();
        } else {
          total -= (item['jumlah'] as num).toInt();
        }
      });

      loaded.sort((a, b) => b['tanggal'].compareTo(a['tanggal']));

      setState(() {
        _data = loaded;
        _saldo = total;
      });
    }
  }

  Future<void> _pickImageFor(String id) async {
  final status = await Permission.photos.request(); // atau Permission.storage untuk SDK < 33
  if (!status.isGranted) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Izin akses galeri ditolak")),
    );
    return;
  }

  final picker = ImagePicker();
  final picked = await picker.pickImage(source: ImageSource.gallery);

  if (picked != null) {
    setState(() {
      _localImages[id] = picked.path;
    });
  }
}

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Saldo : $_saldo',
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _data.length,
                itemBuilder: (context, index) {
                  final item = _data[index];
                  final bgColor = const Color(0xFF469597);
                  final id = item['id'];
                  final imagePath = _localImages[id];

                  return GestureDetector(
                    onTap: () {
                      Navigator.pushNamed(context, '/detail', arguments: item);
                    },
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: bgColor,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: () async {
                              await _pickImageFor(id);
                            },
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Container(
                                width: 60,
                                height: 60,
                                color: Colors.grey.shade200,
                                child: imagePath != null
                                    ? Image.file(
                                        File(imagePath),
                                        width: 60,
                                        height: 60,
                                        fit: BoxFit.cover,
                                      )
                                    : const Icon(Icons.camera_alt,
                                        size: 28, color: Colors.grey),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item['title'],
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: 'Poppins')),
                                const SizedBox(height: 4),
                                Text(item['jenis'],
                                    style: const TextStyle(
                                        color: Colors.white70,
                                        fontSize: 12,
                                        fontFamily: 'Poppins')),
                                Text("Tanggal: ${item['tanggal']}",
                                    style: const TextStyle(
                                        color: Colors.white70,
                                        fontSize: 12,
                                        fontFamily: 'Poppins')),
                                Text("Rp. ${item['jumlah']}",
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Poppins')),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF1E1C4C),
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => AddNoteScreen()),
          );
          fetchData();
        },
      ),
    );
  }
}
