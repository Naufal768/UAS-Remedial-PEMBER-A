import 'package:flutter/material.dart';

class DetailNoteScreen extends StatelessWidget {
  final Map<String, dynamic> data;

  const DetailNoteScreen({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FC),
      appBar: AppBar(
        title: const Text(
          'Detail Data',
          style: TextStyle(
            color: Colors.black,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        centerTitle: true,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        child: ListView(
          children: [
            Container(
              alignment: Alignment.center,
              margin: const EdgeInsets.only(bottom: 16),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(5),
                child: Image.asset('img/book.png', height: 180),
              ),
            ),
            _detailField("Title :", data['title']),
            const SizedBox(height: 12),
            _detailField("Jenis :", data['jenis']),
            const SizedBox(height: 12),
            _detailField("Tanggal :", data['tanggal']),
            const SizedBox(height: 12),
            _detailField("Jumlah :", data['jumlah'].toString()),
            const SizedBox(height: 12),
            _detailField("Deskripsi :", data['deskripsi']),
          ],
        ),
      ),
    );
  }

  Widget _detailField(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
              fontSize: 14,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w500,
            )),
        const SizedBox(height: 4),
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: const Color(0xFF508C9B),
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
          child: Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
              fontSize: 14,
            ),
          ),
        ),
      ],
    );
  }
}
