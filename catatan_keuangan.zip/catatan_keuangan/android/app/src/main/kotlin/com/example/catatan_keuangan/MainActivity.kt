package com.example.catatan_keuangan

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
